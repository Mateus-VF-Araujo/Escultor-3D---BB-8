#include "sculptor.hpp"
#include "math.h"
#include <iostream>
#include <fstream>

Sculptor::Sculptor(int _nx, int _ny, int _nz){

  nx = _nx;
  ny = _ny;
  nz = _nz;
  v = new Voxel**[nx];

  for(int i=0; i<nx; i++){
    v[i] = new Voxel*[ny];
    
    for(int j=0; j<ny; j++){
      v[i][j] = new Voxel[nz];

      for (int k = 0; k < nz; ++k) {
          v[i][j][k].show = false;
      }
    }
  }
}

Sculptor::~Sculptor(){

  for(int i=0; i<nx; i++){

    for(int j=0; j<ny; j++){
      delete[] v[i][j];
    }
    delete[] v[i];
  }
  delete[] v;
}	

void Sculptor::setColor(float r, float g, float b, float a){

  this->r = r;
  this->g = g;
  this->b = b;
  this->a = a;
}

void Sculptor::putVoxel(int x, int y, int z){
  
  if (x >= 0 && x < nx && y >= 0 && y < ny && z >= 0 && z < nz) {
    v[x][y][z].show = true;
    v[x][y][z].r = r;
    v[x][y][z].g = g;
    v[x][y][z].b = b;
    v[x][y][z].a = a;
  }
}

void Sculptor::cutVoxel(int x, int y, int z){
  
  if (x >= 0 && x < nx && y >= 0 && y < ny && z >= 0 && z < nz) {
    v[x][y][z].show = false;
  }
}

void Sculptor::putBox(int x0, int x1, int y0, int y1, int z0, int z1){

  for(int i=x0; i<x1; i++){
    
    for(int j=y0; j<y1; j++){
      
      for(int k=z0; k<z1; k++){
        putVoxel(i,j,k);
      }
    }
  }
}

void Sculptor::cutBox(int x0, int x1, int y0, int y1, int z0, int z1){

  for(int i=x0; i<x1; i++){

    for(int j=y0; j<y1; j++){

      for(int k=z0; k<z1; k++){
        cutVoxel(i,j,k);
      }
    }
  }
}

void Sculptor::putSphere(int xcenter, int ycenter, int zcenter, int radius){

  for(int i=xcenter-radius; i<xcenter+radius; i++){
    
    for(int j=ycenter-radius; j<ycenter+radius; j++){

      for(int k=zcenter-radius; k<zcenter+radius; k++){
        
        if(pow((i-xcenter),2) + pow((j-ycenter),2) + pow((k-zcenter),2) <= pow(radius,2)){
          putVoxel(i,j,k);
        }
      }
    }
  }
}

void Sculptor::cutSphere(int xcenter, int ycenter, int zcenter, int radius){

  for(int i=xcenter-radius; i<xcenter+radius; i++){
    
    for(int j=ycenter-radius; j<ycenter+radius; j++){

      for(int k=zcenter-radius; k<zcenter+radius; k++){

        if(pow((i-xcenter),2) + pow((j-ycenter),2) + pow((k-zcenter),2) <= pow(radius,2)){
          cutVoxel(i,j,k);
        }
      }
    }
  }
}

void Sculptor::putEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz){

  for(int i=xcenter-rx; i<xcenter+rx; i++){

    for(int j=ycenter-ry; j<ycenter+ry; j++){

      for(int k=zcenter-rz; k<zcenter+rz; k++){

        if((pow((i-xcenter),2))/(pow(rx,2)) + (pow((j-ycenter),2))/(pow(ry,2)) + (pow((k-zcenter),2))/(pow(rz,2)) <= 1){
          putVoxel(i,j,k);
        }
      }
    }
  }
}

void Sculptor::cutEllipsoid(int xcenter, int ycenter, int zcenter, int rx, int ry, int rz){
  
  for(int i=xcenter-rx; i<xcenter+rx; i++){

    for(int j=ycenter-ry; j<ycenter+ry; j++){

      for(int k=zcenter-rz; k<zcenter+rz; k++){

        if((pow((i-xcenter),2))/(pow(rx,2)) + (pow((j-ycenter),2))/(pow(ry,2)) + (pow((k-zcenter),2))/(pow(rz,2)) <= 1){
          cutVoxel(i,j,k);
        }
      }
    }
  }
}

void Sculptor::writeOFF(const char* filename){

  std::ofstream fout(filename);
  
  if (!fout) {
      std::cerr << "Houver um erro ao gerar o arquivo " << filename << std::endl;
    
      return;
  }

  int totalVoxels = 0;
  for (int i = 0; i < nx; i++){
    
      for (int j = 0; j < ny; j++){
        
          for (int k = 0; k < nz; k++){
            
              if (v[i][j][k].show){
                  totalVoxels++;
              }
          }
      }
  }

  fout << "OFF\n";
  fout << 8 * totalVoxels << " " << 6 * totalVoxels << " 0\n";

  for (int i = 0; i < nx; i++) {
    
      for (int j = 0; j < ny; j++) {
        
          for (int k = 0; k < nz; k++) {
            
              if (v[i][j][k].show) {
                  fout << i - 0.5 << " " << j + 0.5 << " " << k - 0.5 << "\n";
                  fout << i - 0.5 << " " << j - 0.5 << " " << k - 0.5 << "\n";
                  fout << i + 0.5 << " " << j - 0.5 << " " << k - 0.5 << "\n";
                  fout << i + 0.5 << " " << j + 0.5 << " " << k - 0.5 << "\n";
                  fout << i - 0.5 << " " << j + 0.5 << " " << k + 0.5 << "\n";
                  fout << i - 0.5 << " " << j - 0.5 << " " << k + 0.5 << "\n";
                  fout << i + 0.5 << " " << j - 0.5 << " " << k + 0.5 << "\n";
                  fout << i + 0.5 << " " << j + 0.5 << " " << k + 0.5 << "\n";
              }
          }
      }
  }

  int voxels = 0;
  for (int i = 0; i < nx; i++) {
    
      for (int j = 0; j < ny; j++) {
        
          for (int k = 0; k < nz; k++) {
            
              if (v[i][j][k].show) {
                
                  int voxelsInLayer = voxels * 8;
                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 0 << " " << voxelsInLayer + 3 << " " << voxelsInLayer + 2 << " " << voxelsInLayer + 1 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 4 << " " << voxelsInLayer + 5 << " " << voxelsInLayer + 6 << " " << voxelsInLayer + 7 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 0 << " " << voxelsInLayer + 1 << " " << voxelsInLayer + 5 << " " << voxelsInLayer + 4 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 0 << " " << voxelsInLayer + 4 << " " << voxelsInLayer + 7 << " " << voxelsInLayer + 3 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 3 << " " << voxelsInLayer + 7 << " " << voxelsInLayer + 6 << " " << voxelsInLayer + 2 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                
                  fout << 4 + voxelsInLayer * 0 << " " << voxelsInLayer + 1 << " " << voxelsInLayer + 2 << " " << voxelsInLayer + 6 << " " << voxelsInLayer + 5 << " ";
                  fout << v[i][j][k].r << " " << v[i][j][k].g << " " << v[i][j][k].b << " " << v[i][j][k].a << "\n";

                  voxels++;
              }
          }
      }
  }

  fout.close();
}